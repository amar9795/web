import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;

public class LoginDao {

    int CustomerSignUp(int a, String b, String c, String d, String e, int f, String g, int h, String i, String j,String k,String l,String m,String n,String o ,String p){

        Connection con=null;
        Statement statement=null;
        try{
            con = DBconnection.createConnection();
            con.setAutoCommit(false);
            statement=con.createStatement();
            PreparedStatement ps = con.prepareStatement("insert into user_r1 values(?,?,?,?,?,?) ");
            ps.setInt(1,a);
            ps.setString(2,b);
            ps.setString(3,c);
            ps.setString(4,d);
            ps.setString(5,e);
            ps.setInt(6,f);
            ps.setString(7,g);
            ps.setInt(8,h);
            ps.setString(9,i);
            ps.setString(10,j);
            ps.setString(11,k);
            ps.setString(12,l);
            ps.setString(13,m);
            ps.setString(15,n);
            ps.setString(16,o);
            ps.setString(17,p);


            int z =ps.executeUpdate();

            con.commit();
        }catch (Exception e2) {System.out.println(e2);}

    }

}
