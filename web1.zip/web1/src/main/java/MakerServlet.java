import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/abc.do")
public class MakerServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String role = req.getParameter("user_role");
        if (role.equalsIgnoreCase("Customer")){
            resp.sendRedirect("Customer.html");
        }
        else if (role.equalsIgnoreCase("maker")){
            resp.sendRedirect("Maker.html");
        }
        else if (role.equalsIgnoreCase("checker")){
            resp.sendRedirect("Checker.html");
        }
        else if(role.equalsIgnoreCase("Makerchecker")) {
            resp.sendRedirect("Makerchecker.html");
        }
    }
}
