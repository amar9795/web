import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/userSignup.do")
public class SignUpServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String b=req.getParameter("customerName");
        String c=req.getParameter("dateOfBirth");
        String d=req.getParameter("contactNumber");
        String e=req.getParameter("emailAddress");
        String p=req.getParameter("user_password");
        String m=req.getParameter("user_sex");
        String o=req.getParameter("Select_role");
        String n=req.getParameter("user_location");
        int f = Integer.parseInt(req.getParameter("monthlyIncome"));
        String g=req.getParameter("Profession");
        int h= Integer.parseInt(req.getParameter("totalMonthlyExpense"));
        String i=req.getParameter("designation");
        String l=req.getParameter("dateOfJoining");
        String j=req.getParameter("companyName");

        LoginDao dao = new LoginDao();
        dao.CustomerSignUp("b",)

    }
}
